#include <SFML/Graphics.hpp>
#include <vector>
#include <cmath>
#include <iostream>
 
int main() {
    const float ertefaeAvvalieh = 600.0f;
    const float zaribEntebakhshi = 0.8f;
    const float jazebe = 980.0f; 
    const float epsilon = 0.5f;
    const float shoa = 20.0f; 
    const float ertefaeZamin = 50.0f; 
    sf::RenderWindow window(sf::VideoMode(800, 800), "Faling ball game");

    float ertefae = ertefaeAvvalieh;
    float sorat = 0.0f;

    sf::CircleShape toop(shoa);
    toop.setFillColor(sf::Color::Red);
    toop.setPosition(400.0f - shoa, 800.0f - ertefae - shoa - ertefaeZamin);

    sf::RectangleShape zamin(sf::Vector2f(800.0f, ertefaeZamin));
    zamin.setFillColor(sf::Color(170, 66, 245));
    zamin.setPosition(0, 800.0f - ertefaeZamin);

    sf::Clock clock;

    while (window.isOpen()) {

        sf::Event event;
        
        while (window.pollEvent(event)) {

            if (event.type == sf::Event::Closed)

                window.close();
        }

        float deltaZaman = clock.restart().asSeconds();

        if (ertefae > epsilon) {

            sorat += jazebe * deltaZaman;
            ertefae -= sorat * deltaZaman;

            if (ertefae <= shoa + ertefaeZamin + 20.0f) {

                ertefae = (shoa + ertefaeZamin + 20.0f) + zaribEntebakhshi * (shoa + ertefaeZamin - ertefae + 20.0f);
                sorat = -sorat * zaribEntebakhshi;
                // cout << ertefae << endle;
                // cout << sorat << endle;
            }

            toop.setPosition(400.0f - shoa, 800.0f - ertefae - ertefaeZamin - shoa + 20.0f);
        }

        window.clear(sf::Color::White);
        window.draw(toop);
        window.draw(zamin);
        window.display();
    }

    return 0;
}
