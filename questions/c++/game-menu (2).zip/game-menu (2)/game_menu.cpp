#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <vector>
#include <iostream>

class Button {
public:
    Button(const std::string &text, const sf::Vector2f &position, const sf::Font &font) {
        button.setFont(font);
        button.setString(text);
        button.setCharacterSize(50);
        button.setPosition(position);
        button.setFillColor(sf::Color::White);
        defaultColor = sf::Color::White;
        hoverColor = sf::Color::Yellow;

        sf::FloatRect bounds = button.getLocalBounds();
        button.setOrigin(bounds.width / 2, bounds.height / 2);
    }

    void draw(sf::RenderWindow &window) {
        window.draw(button);
    }

    void update(const sf::Vector2f &mousePos) {
        if (button.getGlobalBounds().contains(mousePos)) {
            if (button.getFillColor() != hoverColor) {
                button.setFillColor(hoverColor);
                hoverSound.play();
            }
        } else {
            button.setFillColor(defaultColor);
        }
    }

    bool isHovered(const sf::Vector2f &mousePos) {
        return button.getGlobalBounds().contains(mousePos);
    }

    bool isClicked(const sf::Vector2f &mousePos, sf::Mouse::Button mouseButton) {
        return isHovered(mousePos) && sf::Mouse::isButtonPressed(mouseButton);
    }

    void setHoverSound(const sf::Sound &sound) {
        hoverSound = sound;
    }

    void setClickSound(const sf::Sound &sound) {
        clickSound = sound;
    }

    void playClickSound() {
        clickSound.play();
    }

private:
    sf::Text button;
    sf::Color defaultColor;
    sf::Color hoverColor;
    sf::Sound hoverSound;
    sf::Sound clickSound;
};

int main() {
    sf::RenderWindow window(sf::VideoMode(1200, 757), "Game Menu");
    window.setFramerateLimit(60);

    sf::Font font;
    if (!font.loadFromFile("arial.ttf")) {
        std::cerr << "Error loading font\n";
        return -1;
    }

    sf::Texture backgroundTexture;
    if (!backgroundTexture.loadFromFile("background.jpg")) {
        std::cerr << "Error loading background image\n";
        return -1;
    }
    sf::Sprite background(backgroundTexture);

    sf::SoundBuffer clickBuffer, hoverBuffer;
    if (!clickBuffer.loadFromFile("click.ogg") || !hoverBuffer.loadFromFile("hover.ogg")) {
        std::cerr << "Error loading sound effects\n";
        return -1;
    }
    sf::Sound clickSound(clickBuffer);
    sf::Sound hoverSound(hoverBuffer);

    std::vector<Button> buttons;
    buttons.emplace_back("Play", sf::Vector2f(600, 280), font);
    buttons.emplace_back("Setting", sf::Vector2f(600, 380), font);
    buttons.emplace_back("Account", sf::Vector2f(600, 480), font);
    buttons.emplace_back("Exit", sf::Vector2f(600, 580), font);

    for (auto &button : buttons) {
        button.setHoverSound(hoverSound);
        button.setClickSound(clickSound);
    }

    while (window.isOpen()) {
        sf::Event event;
        sf::Vector2f mousePos = static_cast<sf::Vector2f>(sf::Mouse::getPosition(window));

        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
            }
        }

        for (auto &button : buttons) {
            button.update(mousePos);
        }

        for (size_t i = 0; i < buttons.size(); ++i) {
            if (buttons[i].isClicked(mousePos, sf::Mouse::Left)) {
                std::cout << "Button " << i << " clicked.\n";
                buttons[i].playClickSound();
                if (i == 3) { 
                    window.close();
                }
            }
        }

        window.clear();
        window.draw(background);
        for (auto &button : buttons) {
            button.draw(window);
        }
        window.display();
    }

    return 0;
}
