#include <SDL2/SDL.h>
#include <iostream>

const int SCREEN_WIDTH = 1600;
const int SCREEN_HEIGHT = 1200;

// Function to draw a cube at a given position with a given size
void drawCube(SDL_Renderer* renderer, int x, int y, int size, int n) {
    int h = size / 2;  // Half size for isometric projection

    // Coordinates for the vertices of the cube
    SDL_Point topFace[4] = {
        {x, y},
        {x + size, y - h},
        {x + 2 * size, y},
        {x + size, y + h}
    };

    SDL_Point leftFace[4] = {
        {x, y},
        {x + size, y + h},
        {x + size, y + size + h},
        {x, y + size}
    };

    SDL_Point rightFace[4] = {
        {x + size, y + h},
        {x + 2 * size, y},
        {x + 2 * size, y + size},
        {x + size, y + size + h}
    };

    // Draw top face
    SDL_SetRenderDrawColor(renderer, 200, 200, 200, 255);  // Light gray
    SDL_RenderDrawLines(renderer, topFace, 4);
    SDL_RenderDrawLine(renderer, topFace[3].x, topFace[3].y, topFace[0].x, topFace[0].y);

    // Draw left face
    SDL_SetRenderDrawColor(renderer, 150, 150, 150, 255);  // Medium gray
    SDL_RenderDrawLines(renderer, leftFace, 4);
    SDL_RenderDrawLine(renderer, leftFace[3].x, leftFace[3].y, leftFace[0].x, leftFace[0].y);

    // Draw right face
    SDL_SetRenderDrawColor(renderer, 100, 100, 100, 255);  // Dark gray
    SDL_RenderDrawLines(renderer, rightFace, 4);
    SDL_RenderDrawLine(renderer, rightFace[3].x, rightFace[3].y, rightFace[0].x, rightFace[0].y);

    // Draw internal grid lines for better visual separation (optional)
    for (int i = 1; i < n; ++i) {
        // Vertical lines on the top face
        SDL_RenderDrawLine(renderer, x + i * size / n, y + i * h / n, x + i * size / n + size, y - h + i * h / n);
        SDL_RenderDrawLine(renderer, x + i * size / n, y - i * h / n, x + size + i * size / n, y + h - i * h / n);

        // Vertical lines on the left face
        SDL_RenderDrawLine(renderer,  x + i * size / n, y + i * h / n, x + i * size / n, y + size + i * h/n);
        SDL_RenderDrawLine(renderer, x, y + i * size / n, x + size, y + h + i * size / n);

        // Vertical lines on the right face
        SDL_RenderDrawLine(renderer, x + size + i * size / n, y + h - i * h / n, x + size + i * size / n, y + size + h - i * h / n);
        SDL_RenderDrawLine(renderer, x + size, y + h + i * size / n, x + 2 * size, y + i * size / n);
    }
}

int main(int argc, char* argv[]) {
    int n;
    std::cout << "Enter the size of the Rubik's cube (n): ";
    std::cin >> n;

    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        std::cerr << "SDL could not initialize! SDL_Error: " << SDL_GetError() << std::endl;
        return 1;
    }

    SDL_Window* window = SDL_CreateWindow("3D Rubik's Cube", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN);
    if (!window) {
        std::cerr << "Window could not be created! SDL_Error: " << SDL_GetError() << std::endl;
        SDL_Quit();
        return 1;
    }

    SDL_Renderer* renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    if (!renderer) {
        std::cerr << "Renderer could not be created! SDL_Error: " << SDL_GetError() << std::endl;
        SDL_DestroyWindow(window);
        SDL_Quit();
        return 1;
    }

    bool quit = false;
    SDL_Event e;

    while (!quit) {
        while (SDL_PollEvent(&e) != 0) {
            if (e.type == SDL_QUIT) {
                quit = true;
            }
        }

        SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
        SDL_RenderClear(renderer);

        // Draw a Rubik's cube in the center of the screen
        drawCube(renderer, SCREEN_WIDTH / 2 - 200, SCREEN_HEIGHT / 2 - 200, 240, n);

        SDL_RenderPresent(renderer);
    }

    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();

    return 0;
}
