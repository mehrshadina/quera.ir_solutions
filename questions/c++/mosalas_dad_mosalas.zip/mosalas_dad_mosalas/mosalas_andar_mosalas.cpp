#include <SFML/Graphics.hpp>
#include <cmath>

void drawInvertedKochSnowflake(sf::RenderWindow &window, sf::Vector2f a, sf::Vector2f b, int depth) {
    if (depth == 0) {
        sf::Vertex line[] = {
            sf::Vertex(a),
            sf::Vertex(b)
        };
        window.draw(line, 2, sf::Lines);
        return;
    }

    sf::Vector2f u = a + (b - a) / 3.0f;
    sf::Vector2f v = b + (a - b) / 3.0f;

    sf::Vector2f w = u + sf::Vector2f((v.x - u.x) * cos(-M_PI / 3.0f) - (v.y - u.y) * sin(-M_PI / 3.0f),
                                      (v.x - u.x) * sin(-M_PI / 3.0f) + (v.y - u.y) * cos(-M_PI / 3.0f));

    drawInvertedKochSnowflake(window, a, u, depth - 1);
    drawInvertedKochSnowflake(window, u, w, depth - 1);
    drawInvertedKochSnowflake(window, w, v, depth - 1);
    drawInvertedKochSnowflake(window, v, b, depth - 1);
}

int main() {
    sf::RenderWindow window(sf::VideoMode(800, 800), "Inverted Koch Snowflake");

    sf::Vector2f pointA(400, 560);
    sf::Vector2f pointB(600, 200);
    sf::Vector2f pointC(200, 200); 

    int depth = 2;

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                window.close();
        }

        window.clear();

        drawInvertedKochSnowflake(window, pointA, pointB, depth);
        drawInvertedKochSnowflake(window, pointB, pointC, depth);
        drawInvertedKochSnowflake(window, pointC, pointA, depth);

        window.display();
    }

    return 0;
}
