Ensure SFML is installed and properly linked in your project.
Compile the program with appropriate flags to link SFML. For example:
bash
Copy code
g++ -o InvertedKochSnowflake InvertedKochSnowflake.cpp -lsfml-graphics -lsfml-window -lsfml-system
Run the compiled program:
bash
Copy code
./InvertedKochSnowflake
