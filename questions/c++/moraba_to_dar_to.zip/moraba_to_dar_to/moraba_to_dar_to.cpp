#include <SFML/Graphics.hpp>
#include <cmath>

void drawDiagonalsAndSquares(sf::RenderWindow &window, sf::Vector2f bottomLeft, sf::Vector2f topRight, int depth) {
    if (depth == 0) {
        return;
    }

    sf::Vector2f bottomRight(topRight.x, bottomLeft.y);
    sf::Vector2f topLeft(bottomLeft.x, topRight.y);
    sf::Vector2f center = (bottomLeft + topRight) / 2.0f;
    sf::Vector2f halfSize = (topRight - bottomLeft) / 2.0f;

    sf::Vertex diagonal1[] = {
        sf::Vertex(bottomLeft),
        sf::Vertex(topRight)
    };
    sf::Vertex diagonal2[] = {
        sf::Vertex(bottomRight),
        
        sf::Vertex(topLeft)
    };
    window.draw(diagonal1, 2, sf::Lines);
    window.draw(diagonal2, 2, sf::Lines);

    sf::Vertex square[] = {
        sf::Vertex(bottomLeft),
        sf::Vertex(bottomRight),
        sf::Vertex(topRight),
        sf::Vertex(topLeft),
        sf::Vertex(bottomLeft) 
    };
    window.draw(square, 5, sf::LinesStrip);

    if (depth > 1) {
        sf::Vector2f smallerBottomLeft = center - halfSize / 2.0f;
        sf::Vector2f smallerTopRight = center + halfSize / 2.0f;

        sf::Vertex smallerSquare[] = {
            sf::Vertex(smallerBottomLeft),
            sf::Vertex(sf::Vector2f(smallerTopRight.x, smallerBottomLeft.y)),
            sf::Vertex(smallerTopRight),
            sf::Vertex(sf::Vector2f(smallerBottomLeft.x, smallerTopRight.y)),
            sf::Vertex(smallerBottomLeft) 
        };
        window.draw(smallerSquare, 5, sf::LinesStrip);
    }

    drawDiagonalsAndSquares(window, bottomLeft, center, depth - 1);
    drawDiagonalsAndSquares(window, center, topRight, depth - 1);
    drawDiagonalsAndSquares(window, bottomRight, center, depth - 1);
    drawDiagonalsAndSquares(window, center, topLeft, depth - 1);
}

int main() {
    sf::RenderWindow window(sf::VideoMode(800, 800), "Squares with Diagonals and Smaller Squares");

    sf::Vector2f bottomLeft(200, 600);
    sf::Vector2f topRight(600, 200);
    int depth = 4; // Adjust depth for more subdivisions

    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                window.close();
        }

        window.clear();

        drawDiagonalsAndSquares(window, bottomLeft, topRight, depth);

        window.display();
    }

    return 0;
}
