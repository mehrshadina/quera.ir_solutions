import datetime
import csv
import matplotlib.pyplot as plt

STORM_WIND_SPEED = 35

def load_data(file_path):
    records = []
    with open(file_path, mode='r', encoding='utf-8') as file:
        reader = csv.DictReader(file)
        for row in reader:
            record = {
                'datetime': datetime.datetime.strptime(row['datetime'], '%Y-%m-%d'),
                'windspeed': float(row['windspeed']),
                'conditions': row['conditions'],
                'temp': float(row['temp']),
                'tempmax': float(row['tempmax']),
                'tempmin': float(row['tempmin']),
                'preciptype': row['preciptype'],
                'month': datetime.datetime.strptime(row['datetime'], '%Y-%m-%d').strftime('%B')
            }
            records.append(record)
    return records

def rainy_days(data):
    rainy_days = sum(1 for record in data if 'rain' in record['preciptype'])
    total_days = len(data)
    return (rainy_days / total_days) * 100

def min_temp(data):
    return min(data, key=lambda x: x['tempmin'])['datetime']

def max_temp(data):
    return max(data, key=lambda x: x['tempmax'])['datetime']

def get_storm_days(data):
    return [record['datetime'] for record in data if record['windspeed'] >= STORM_WIND_SPEED]

def plot_temperature(data, month):
    month_data = [record for record in data if record['month'] == month]
    dates = [record['datetime'] for record in month_data]
    temps = [record['temp'] for record in month_data]
    
    plt.figure(figsize=(10, 5))
    plt.plot(dates, temps, marker='o')
    plt.title(f'Temperature in {month}')
    plt.xlabel('Date')
    plt.ylabel('Temperature (°C)')
    plt.grid(True)
    plt.show()

def plot_windspeed(data):
    dates = [record['datetime'] for record in data]
    windspeeds = [record['windspeed'] for record in data]
    
    plt.figure(figsize=(10, 5))
    plt.plot(dates, windspeeds, marker='o')
    plt.title('Wind Speed Over Time')
    plt.xlabel('Date')
    plt.ylabel('Wind Speed (mph)')
    plt.grid(True)
    plt.show()

def plot_condition(data):
    condition_counts = {}
    for record in data:
        condition = record['conditions']
        condition_counts[condition] = condition_counts.get(condition, 0) + 1
    
    labels = condition_counts.keys()
    sizes = condition_counts.values()
    
    plt.figure(figsize=(8, 8))
    plt.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=140)
    plt.title('Condition Distribution')
    plt.show()


data = load_data('Daily_Weather_Report.csv')

rainy_days_percentage = rainy_days(data)
max_temp_date = max_temp(data)
min_temp_date = min_temp(data)
storm_days = get_storm_days(data)

print("What percentage of days in 2023 in New York were rainy?")
print(f"{rainy_days_percentage:.2f}%")
print("The highest temperature occurred on:")
print(max_temp_date)
print("The lowest temperature occurred on:")
print(min_temp_date)
print("Days with potential storm:")
for storm in storm_days:
    print(str(storm))

print('\n\n\n\n')

while True:
    print("\nChoose an option to view the analysis:")
    print("1. Plot temperature")
    print("2. Plot wind speed")
    print("3. Plot condition")
    print("4. Exit")
    
    choice = input("Enter your choice: ")
    
    if choice == '1':
        month = input("Enter the month (first char must be capital) (January, ...): ")
        plot_temperature(data, month)

    elif choice == '2':
        plot_windspeed(data)

    elif choice == '3':
        plot_condition(data)

    elif choice == '4':
        break

