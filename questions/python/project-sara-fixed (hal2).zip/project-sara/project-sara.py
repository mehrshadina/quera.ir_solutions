import csv
from datetime import datetime
import matplotlib.pyplot as plt

file_path = 'Daily_Weather_Report.csv'
data = []

with open(file_path, 'r') as csvfile:
    csvreader = csv.DictReader(csvfile)
    for row in csvreader:
        row['datetime'] = datetime.strptime(row['datetime'], '%Y-%m-%d')
        row['tempmax'] = float(row['tempmax'])
        row['tempmin'] = float(row['tempmin'])
        row['temp'] = float(row['temp'])
        row['windspeed'] = float(row['windspeed'])
        row['preciptype'] = row['preciptype'].split(',')
        row['month'] = row['datetime'].strftime('%B')
        data.append(row)

rainy_days = sum(1 for row in data if 'rain' in row['preciptype'])
total_days = len(data)
rainy_days_percentage = (rainy_days / total_days) * 100
max_temp_date = max(data, key=lambda x: x['tempmax'])['datetime']
min_temp_date = min(data, key=lambda x: x['tempmin'])['datetime']
storm_days = []

for row in data:
    if row['windspeed'] >= 35:
         storm_days.append(str(row['datetime']))


def temperature_by_month(month):
    month_data = []
    for row in data:
        if row['month'] == month:
            month_data.append(row)
    
    dates = []
    for row in month_data:
        dates.append(row['datetime'])
    
    temps = []
    for row in month_data:
        temps.append(row['temp'])
    
    plt.figure(figsize=(10, 5))
    plt.plot(dates, temps, marker='o')
    plt.title(f'Temperature in {month}')
    plt.xlabel('Date')
    plt.ylabel('Temperature (°C)')
    plt.grid(True)
    plt.show()

def windspeed_over_time():
    dates = []
    for row in data:
        dates.append(row['datetime'])

    wind_speeds = []
    for row in data :
        wind_speeds.append(row['windspeed'])
    
    plt.figure(figsize=(10, 5))
    plt.plot(dates, wind_speeds, marker='o')
    plt.title('Wind Speed Over Time')
    plt.xlabel('Date')
    plt.ylabel('Wind Speed (mph)')
    plt.grid(True)
    plt.show()

def condition_pie_chart():
    condition_counts = {}
    for row in data:
        conditions = row['conditions'].split(', ')
        for condition in conditions:
            if condition in condition_counts:
                condition_counts[condition] += 1
            else:
                condition_counts[condition] = 1
    
    labels = list(condition_counts.keys())
    sizes = list(condition_counts.values())
    
    plt.figure(figsize=(8, 8))
    plt.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=140)
    plt.title('Pie chart')
    plt.show()

def main_menu():
    print(
        "چند درصد از روزهای سال ۲۰۲۳ در نیویورک بارانی بوده است؟", 
        f"{rainy_days_percentage:.2f}%"
        )
    print(
        "بیشترین دما در تاریخ:", 
        f"{max_temp_date}"
        )
    print(
        "کمترین دما در تاریخ:", 
        f"{min_temp_date}"
        )
    print(
        "روزهایی که احتمال طوفان داشته‌اند:", 
        f"{storm_days}"
        )

    while True:
        print(
            "\nEnter a number to plot the data:\n"
            "1. Plot wind speed over time\n"                
            "2. Plot temperature by month\n"
            "3. Plot condition pie chart"
            )
        print("4. Exit")
        
        choice = input("Enter your number: ")
        
        if choice == '1':
            windspeed_over_time()
        elif choice == '2':
            month = input("Enter the month (January, February, March, ...): ")
            temperature_by_month(month)
        elif choice == '3':
            condition_pie_chart()
        elif choice == '4':
            break
        else:
            print("Invalid choice.")
            break

main_menu()
