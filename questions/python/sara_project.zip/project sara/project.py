import csv
from datetime import datetime
import matplotlib.pyplot as plt

def windspeed_over_time(weatherData):
    dates = []
    for row in weatherData:
        dates.append(row['datetime'])

    speeds = []
    for row in weatherData :
        speeds.append(row['windspeed'])
    
    plt.figure(figsize=(10, 5))
    plt.plot(dates, speeds, marker='o')
    plt.title('Wind Speed Over Time')
    plt.xlabel('Date')
    plt.ylabel('Wind Speed (mph)')
    plt.grid(True)
    plt.show()

def condition_pie_chart(weatherData):
    condition_counts = {}
    for row in weatherData:
        conditions = row['conditions'].split(', ')

        for condition in conditions:

            if condition in condition_counts:
                condition_counts[condition] += 1
            else:
                condition_counts[condition] = 1
    
    labels = list(condition_counts.keys())
    sizes = list(condition_counts.values())
    
    plt.figure(figsize=(7, 7))
    plt.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=140)
    plt.title('Pie graph')
    plt.show()

def temperature_by_month(month, weatherData):
    month_data = []
    for row in weatherData:
        if row['month'] == month:
            month_data.append(row)
    
    dates = []
    for row in month_data:
        dates.append(row['datetime'])
    
    temps = []
    for row in month_data:
        temps.append(row['temp'])
    
    plt.figure(figsize=(10, 5))
    plt.plot(dates, temps, marker='o')
    plt.title(f'Temperature in {month}')
    plt.xlabel('Date')
    plt.ylabel('Temperature (°C)')
    plt.grid(True)
    plt.show()


def main():
    csvfile = open('Daily_Weather_Report.csv', 'r')
    csvreader = csv.DictReader(csvfile)

    weatherData = []

    for row in csvreader:
        row['datetime'] = datetime.strptime(row['datetime'], '%Y-%m-%d')
        row['tempmax'] = float(row['tempmax'])
        row['tempmin'] = float(row['tempmin'])
        row['temp'] = float(row['temp'])
        row['windspeed'] = float(row['windspeed'])
        row['preciptype'] = row['preciptype'].split(',')
        row['month'] = row['datetime'].strftime('%B')

        weatherData.append(row)

    rainy_days = 0
    for row in weatherData:

        if 'rain' in row['preciptype']:
            rainy_days += 1

    total_days = len(weatherData)
    rainyPercentage = (rainy_days / total_days) * 100

    maxTemp = max(weatherData, key=lambda x: x['tempmax'])['datetime']

    minTemp = min(weatherData, key=lambda x: x['tempmin'])['datetime']

    stormDays = []

    for row in weatherData:
        if row['windspeed'] >= 35:
            stormDays.append(str(row['datetime']))

        print("درصد روز های بارانی سال 2023 در نیویورک:", f"{rainyPercentage:.2f}%")
        print("بیشترین دما در تاریخ:", maxTemp)
        print("کمترین دما در تاریخ:", minTemp)
        print("روزهایی که احتمال طوفان داشته‌اند:")
        for thing in stormDays:
            print(thing)

        while True:
            print(
                "\nWhat are you searching for?\n"
                "1) Plot wind speed-time\n"                
                "2) Plot temperature-month\n"
                "3) Plot condition pie\n"
                "4) Exit"
                )
            
            choice = input("Enter your number: ")
            
            if choice == '1':
                windspeed_over_time(weatherData)

            elif choice == '2':
                month = input("Enter the month (February, March, etc ")
                temperature_by_month(month, weatherData)

            elif choice == '3':
                condition_pie_chart(weatherData)

            elif choice == '4':
                break

main()