import matplotlib.pyplot as plt
import json

def process_actions(users_data, actions_log):
    for action in actions_log:
        operation, username, *args = action.split()

        if operation == 'ADD':
            amount = int(args[0])
            if username in users_data:
                users_data[username]['balance'] += amount

        elif operation == 'CREATE':
            age = int(args[0])
            users_data[username] = {'balance': 0, 'age': age}

        elif operation == 'DELETE':
            if username in users_data:
                del users_data[username]

    return users_data

def save_users_to_json(users_data, filename):
    with open(filename, 'w') as file:
        json.dump(users_data, file)

def plot_age_histogram(users_data, filename):
    ages = [info['age'] for info in users_data.values()]
    plt.hist(ages, bins=range(min(ages), max(ages) + 2), edgecolor='black')
    plt.xlabel('Age')
    plt.ylabel('Frequency')
    plt.title('Age Distribution')
    plt.savefig(filename)
    plt.show()

with open('users.json', 'r') as file:
    all_users_data = json.load(file)

with open('actions.log', 'r') as file:
    all_actions_log = file.readlines()

all_users_data = process_actions(all_users_data, all_actions_log)

with open('users.json', 'w') as file:
    json.dump(all_users_data, file)
plot_age_histogram(all_users_data, 'histogram.png')
