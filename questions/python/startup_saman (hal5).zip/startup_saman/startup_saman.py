import json
import matplotlib.pyplot as plt

class UserManager:
    def __init__(self, users_file, actions_file):
        self.users_file = users_file
        self.actions_file = actions_file
        self.all_users = self.load_users()
        self.all_actions = self.load_actions()
        
    def load_users(self):
        with open(self.users_file, 'r') as file:
            return json.load(file)
        
    def load_actions(self):
        with open(self.actions_file, 'r') as file:
            return file.readlines()
    
    def process(self):
        for action in self.all_actions:
            line = action.split()
            ask = line[0]
            id = line[1]

            match ask:
                case 'ADD':
                    amount = int(line[2])
                    if id in self.all_users:
                        self.all_users[id]['balance'] += amount

                case 'CREATE':
                    age = int(line[2])
                    if id in self.all_users:
                        self.all_users[id]['age'] = age
                    else:
                        self.all_users[id] = {'balance': 0, 'age': age}

                case 'DELETE':
                    if id in self.all_users:
                        del self.all_users[id]

    def save_users(self):
        with open(self.users_file, 'w') as file:
            json.dump(self.all_users, file)
    
    def plot_histogram(self):
        ages = [info['age'] for info in self.all_users.values()]
        
        plt.hist(ages, bins=range(min(ages), max(ages) + 2), edgecolor='black'
        )
        plt.xlabel('Age')
        plt.ylabel('Frequency')
        plt.title('Histogram of Ages')
        plt.savefig('hist.png')
        plt.show()

def main():
    user_manager = UserManager('users.json', 'actions.log')
    user_manager.process()
    user_manager.save_users()
    user_manager.plot_histogram()

if __name__ == "__main__":
    main()
