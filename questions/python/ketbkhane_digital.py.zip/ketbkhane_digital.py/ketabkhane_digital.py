books_dict = {}
books_2 = {''}
with open('books2.txt', 'r') as book2:
    for book in book2:
        if book.strip() in books_dict:
            books_dict[book.strip()] += 1
        else:
            books_dict[book.strip()] = 1
        books_2.add(book.strip())

with open('books1.txt', 'r') as book1: 
    for book in book1:
        if book.strip() in books_dict:
            books_dict[book.strip()] += 1
        else:
            books_dict[book.strip()] = 1
        
    book1.seek(0)
    for book in book1:
        if book in books_2:
            del books_dict[book] 

sorted_by_title = sorted(books_dict.items(), key=lambda x: x[0])
books = sorted(sorted_by_title, key=lambda x: -x[1])
print(*books)

with open('output.txt', 'w') as output:
    for book_name, n in books:
        output.write("{} - {}".format(book_name, n))
        output.write('\n')