import csv
from datetime import datetime
import matplotlib.pyplot as plt

data = []

with open('Daily_Weather_Report.csv', 'r') as csvfile:
    csvreader = csv.DictReader(csvfile)
    for row in csvreader:
        row['datetime'] = datetime.strptime(row['datetime'], '%Y-%m-%d')
        row['tempmax'] = float(row['tempmax'])
        row['tempmin'] = float(row['tempmin'])
        row['temp'] = float(row['temp'])
        row['windspeed'] = float(row['windspeed'])
        row['preciptype'] = row['preciptype'].split(',')
        row['month'] = row['datetime'].strftime('%B')
        data.append(row)

ruzaye_barani = sum(1 for row in data if 'baran' in row['preciptype'])
kul_ruzha = len(data)
neshane_ruzaye_barani = (ruzaye_barani / kul_ruzha) * 100
ruzaye_darmantaraf_dame_bish = max(data, key=lambda x: x['tempmax'])['datetime']
ruzaye_kamtarin_dame_bish = min(data, key=lambda x: x['tempmin'])['datetime']
ruzaye_tufani = []

for row in data:
    if row['windspeed'] >= 35:
        ruzaye_tufani.append(str(row['datetime']))

print("Cheand Darsade az Ruzaye Sal ۲۰۲۳ dar New York Barani Budeh Ast?")
print(f"{neshane_ruzaye_barani:.2f}%")
print("Bishtarin Dame Bish dar Tarikh:")
print(ruzaye_darmantaraf_dame_bish)
print("Kamtarin Dame Bish dar Tarikh:")
print(ruzaye_kamtarin_dame_bish)
print("Ruzhaye ke Ehtemal Tufan Dashtand:")
print(ruzaye_tufani)


def dame_bish_baraye_hameh_mah(mah):
    mah_data = [row for row in data if row['month'] == mah]
    dataye_mah = [row['datetime'] for row in mah_data]
    daramadha = [row['temp'] for row in mah_data]
    plt.figure(figsize=(10, 5))
    plt.plot(dataye_mah, daramadha, marker='o')
    plt.title(f'Dame Bish Dar {mah}')
    plt.xlabel('Ruz')
    plt.ylabel('Dame Bish (°C)')
    plt.grid(True)
    plt.show()


def sorate_badiro_baraye_zaman():
    dataye_mah = [row['datetime'] for row in data]
    sorathaye_badi = [row['windspeed'] for row in data]
    plt.figure(figsize=(10, 5))
    plt.plot(dataye_mah, sorathaye_badi, marker='o')
    plt.title('Sorate Badi Baraye Zaman')
    plt.xlabel('Ruz')
    plt.ylabel('Sorate Badi (mph)')
    plt.grid(True)
    plt.show()

def sharte_pie_chart():
    shart_counts = {}
    for row in data:
        shoroot = row['shoroot'].split(', ')
        for shart in shoroot:
            if shart in shart_counts:
                shart_counts[shart] += 1
            else:
                shart_counts[shart] = 1
    
    etela = list(shart_counts.keys())
    ahdafe = list(shart_counts.values())
    plt.figure(figsize=(8, 8))
    plt.pie(ahdafe, labels=etela, autopct='%1.1f%%', startangle=140)
    plt.title('Diagram Pi')
    plt.show()


while True:
    text = (
        "\nVared kardan addadi baraye neshan dade kardan dadeh haye:\n"
        "1. Neshan dade kardan sorate badi baraye zaman\n"                
        "2. Neshan dade kardan dame bish baraye har mah\n"
        "3. Neshan dade kardan diagram pi shart ha\n"
        "4. Khoroj\n\n"
        "Addadi ra vared konid: "
        )
    
    choice = input(text)
    
    if choice == '1':
        sorate_badiro_baraye_zaman()

    elif choice == '2':
        mah = input("Mah ra vared konid (January, February, March, ...): ")
        dame_bish_baraye_hameh_mah(mah)

    elif choice == '3':
        sharte_pie_chart()

    elif choice == '4':
        break


