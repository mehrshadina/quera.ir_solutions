import json
import csv

file = open("Data.json", "r")
json_data = json.load(file)

for category in json_data["products"]:
    categoryy = category["category"]
    items = category["items"]
    items = sorted(
        items, 
        key=lambda x: x["current_stock"], 
        reverse=True
        )
    csv_filename = "%s_sorted.csv"%categoryy
    csv_file = open(csv_filename, "w")
    csv_file.write("code, name, initial_stock, current_stock, sold")
    for row in items:
        text = ','.join(map(str, row.values())) + '\n'
        csv_file.write(text)

text = ""
count = 1
for category in json_data["products"]:
    categoryy = category["category"]
    items = category["items"]
    max_stock_item = max(
        items, 
        key=lambda x: x["current_stock"]
        )
    text += f"{count}. {categoryy}\n"
    text += f"highest stock: {max_stock_item['name']} - Code: {max_stock_item['code']} - Current Stock: {max_stock_item['current_stock']}\n\n"
    count += 1

with open("report.txt", "w") as report_file:
    report_file.write(text)

print("Process completed susccessfully!")
