# here we count the number of books
def counter(books1, books2):
    bookCount,booksName1 = dict(), set()
    for book in books1:
        nameOfThisBook = book.strip()
        #print(nameOfThisBook)

        if nameOfThisBook in bookCount:
            #print('im here')
            bookCount[nameOfThisBook] += 1

        else:
            bookCount[nameOfThisBook] = 1

        booksName1.add(nameOfThisBook)

    for book in books2:
        nameOfThisBook = book.strip()
        if nameOfThisBook in booksName1:
            del bookCount[nameOfThisBook]
        elif nameOfThisBook in bookCount:
            bookCount[nameOfThisBook] += 1
        else:
            bookCount[nameOfThisBook] = 1
    
    return bookCount

# here i save the information in .txt file.
def save_information(bookCount):
    sorted_books = sorted(bookCount.items(), key=lambda x: (-x[1], x[0]))
    print(sorted_books)
    file = open('output.txt', 'w')
    for book, count in sorted_books:
        file.write(f"{book} - {count}\n")

def main():
    books1 = open('books1.txt', 'r')
    books2 = open('books2.txt', 'r')

    books = counter(books1, books2)
    save_information(books)