student_records = []
num_students = int(input("Enter the number of students: "))

for items in range(num_students):
    stud_info = input("Enter student information (ID Firstname Lastname Grade1 Weight1 Grade2 Weight2 ...): ").split()
    
    grad = list(map(float, stud_info[3:]))
    grades, weights = grad[0::2], grad[1::2]
    weighted_sum = sum(g * w for g, w in zip(grades, weights))
    average_g = round(weighted_sum / sum(weights), 2)

    student_record = (
        stud_info[0], f"{stud_info[1]} {stud_info[2]}", sum(weights),
        average_g
    )
    # print(student_record)
    student_records.sort(key=lambda x: (-x[3], x[0]))
    student_records.append(student_record)


file = open('result.csv', 'w')
header = 'StudentNumber, FullName, NumOfUnits, Average\n'
file.write(header)

for record in student_records:
    #print(record)
    line = (f"
            {record[0]}, 
            {record[1]}, 
            {record[2]}, 
            {record[3]}\n"
            )
    file.write(line)



