import json

def read_file(write=False, text=None):
        with open("Data.json", "r") as file:
            json_data = json.load(file)
        
        return json_data

def save_information(text):
    with open("report.txt", "w") as report_file:
        report_file.write(text)
        print("File saved.")
        

def main():
    store_datas = read_file()

    for cat in store_datas["products"]:
        products = sorted(cat["items"], key=lambda x: x["current_stock"], reverse=True)
        csv_filename = "{}_sorted.csv".format(cat["category"])
        csv_file = open(csv_filename, "w")
        csv_file.write("code, name, initial_stock, current_stock, sold")

        for row in products:
            #print(row)
            text = ','.join(map(str, row.values())) + '\n'
            #print(text, end='')
            csv_file.write(text)

    message = ""
    for cat in store_datas["products"]:
        items = cat["items"]
        maximum_items = max(items, key=lambda x: x["current_stock"])
        message += cat["category"] + '\n'
        message += f"highest stock: {maximum_items['name']} - Current Stock: {maximum_items['current_stock']}\n\n"

    save_information(message)

main()