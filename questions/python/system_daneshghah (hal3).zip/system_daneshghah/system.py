def main(daneshjooha = []):
    tedad_daneshjooha = int(input())

    for adad in range(tedad_daneshjooha):
        etelaat_daneshjoo = input().split()
        
        hame_nomarat = list(map(float, etelaat_daneshjoo[3:]))
        nomarat = hame_nomarat[0::2]
        zarayeb = hame_nomarat.remove(nomarat)

        majmoo_zaribdar = 0
        for nomre, zarib in zip(nomarat, zarayeb):
            hasel = nomre * zarib
            majmoo_zaribdar += hasel

        moadel = round(majmoo_zaribdar / sum(zarayeb), 2)

        esm_kamel = "%s %s"%(etelaat_daneshjoo[1], 
                             etelaat_daneshjoo[2])
        
        daneshjoo = (
            etelaat_daneshjoo[0], esm_kamel,
            sum(zarayeb), moadel)
        
        daneshjooha.append(daneshjoo)
        
    daneshjooha.sort(key=lambda x: x[0])
    daneshjooha.sort(key=lambda x: -x[3])

    return daneshjooha

daneshjooha = main()

with open('result.csv', 'w') as csvfile:
        khat_avval = 'shomare_daneshjoo, nam_kamel, tedad_vahedha, moadel\n'
        csvfile.write(khat_avval)
        
        for daneshjoo in daneshjooha:
            csvfile.write(
            f'{daneshjoo[0]}, {daneshjoo[1]}, {daneshjoo[2]}, {daneshjoo[3]}\n'
        )