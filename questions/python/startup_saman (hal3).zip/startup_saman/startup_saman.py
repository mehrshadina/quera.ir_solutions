import matplotlib.pyplot as plt
import json

file1, file2 = open('users.json', 'r'), open('actions.log', 'r')
ham_userha = json.load(file1)
ham_actionha = file2.readlines()

def process():
    for karbar in ham_actionha:
        khat_tarahi_shode = karbar.split()
        emr, ersal_konande = khat_tarahi_shode[0], khat_tarahi_shode[1]


        if emr == 'DELETE':

            if ersal_konande in ham_userha:
                del ham_userha[ersal_konande]


        elif emr == 'ADD':
            meghdare_emr = int(khat_tarahi_shode[2])

            if ersal_konande in ham_userha:
                ham_userha[ersal_konande]['mojoodi'] += meghdare_emr

        elif emr == 'CREATE':
            sen = int(khat_tarahi_shode[2])

            if ersal_konande in ham_userha:
                ham_userha[ersal_konande]['sen'] = sen

            else:
                ham_userha[ersal_konande] = {'mojoodi': 0, 'sen': sen}

        
def proceess_1():
    file = open('users.json', 'w')
    json.dump(ham_userha, file)

    senha = []
    for etelaat in ham_userha.values():
        senha.append(etelaat['sen'])

    plt.hist(
        senha, bins = range(min(senha), max(senha) + 2), edgecolor='black'
        )
    plt.xlabel('sen')
    plt.ylabel('tekrar')
    plt.title('Taarikhchah-e Senha')
    plt.savefig('hist.png')
    plt.show()


process()
proceess_1()
