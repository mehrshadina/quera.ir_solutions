import json, csv

class StoreDataProcessor:
    def __init__(self, json_filename):
        self.json_filename = json_filename
        self.store = self.load_data()

    def load_data(self):
        with open(self.json_filename, "r") as file:
            return json.load(file)

    def sort_products_and_save_to_csv(self):
        for product in self.store["products"]:
            products = sorted(product["items"], key=lambda varible: varible["current_stock"], reverse=True)
            this_category = product['category']
            csv_filename = f"{this_category}_sorted.csv"
            with open(csv_filename, "w", newline='') as csv_file:
                writer = csv.writer(csv_file)
                writer.writerow(["code", "name", "initial_stock", "current_stock", "sold"])
                for row in products:
                    writer.writerow(row.values())

    def generate_report(self):
        report = ""
        for product in self.store["products"]:
            maximum_items = max(product["items"], key=lambda varible: varible["current_stock"])
            report += (
                f"{product['category']}\n" 
                f"highest stock: {maximum_items['name']}\n"
                f"Stocks at this time: {maximum_items['current_stock']}\n\n"
                )
        
        with open("report.txt", "w") as report_file:
            report_file.write(report)
        print("Report file saved.")

    def process(self):
        self.sort_products_and_save_to_csv()
        self.generate_report()


processor = StoreDataProcessor("Data.json")
processor.process()
