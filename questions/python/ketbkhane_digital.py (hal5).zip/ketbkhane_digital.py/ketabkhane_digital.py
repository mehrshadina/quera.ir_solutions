class BookManager:
    def __init__(self, file1, file2, output_file):
        self.file1 = file1
        self.file2 = file2
        self.output_file = output_file
        self.book_count = {}
        self.books_name1 = set()

    def process_books(self):
        self._read_books(self.file1, initial=True)
        self._read_books(self.file2, initial=False)
        sorted_books = self._sort_books()
        self._write_output(sorted_books)

    def _read_books(self, file_name, initial):
        with open(file_name, 'r') as file:
            for book in file:
                real_book = book.strip()
                if initial:
                    self._add_or_increment_book(real_book)
                    self.books_name1.add(real_book)
                else:
                    self._process_book_from_second_file(real_book)

    def _add_or_increment_book(self, book):
        if book in self.book_count:
            self.book_count[book] += 1
        else:
            self.book_count[book] = 1

    def _process_book_from_second_file(self, book):
        if book in self.books_name1:
            if book in self.book_count:
                del self.book_count[book]
        else:
            self._add_or_increment_book(book)

    def _sort_books(self):
        return sorted(self.book_count.items(), key=lambda x: (-x[1], x[0]))

    def _write_output(self, sorted_books):
        with open(self.output_file, 'w') as file:
            for book, count in sorted_books:
                file.write(f"{book} - {count}\n")

def main():
    manager = BookManager('books1.txt', 'books2.txt', 'output.txt')
    manager.process_books()

if __name__ == "__main__":
    main()
