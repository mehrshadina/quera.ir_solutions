import pygame, sys

def shapes():
    for row in range(boardRows):
        for col in range(boardCols):
            if board[row][col] == 1:

                pygame.draw.circle(
                    display, 
                    circleColorCode, 
                    (int(col * squareSize + squareSize//2), 
                     int(row * squareSize + squareSize//2)), 
                     circleRadios, 
                     circleWidth
                     )

            elif board[row][col] == 2:

                pygame.draw.line(
                    display, 
                    crossColorCode, 
                    (col * squareSize + Space, row * squareSize + squareSize - Space), 
                    (col * squareSize + squareSize - Space, row * squareSize + Space), 
                    crossWidth
                    )
                
                pygame.draw.line(
                    display, 
                    crossColorCode, 
                    (col * squareSize + Space, row * squareSize + Space), 
                    (col * squareSize + squareSize - Space, row * squareSize + squareSize - Space), 
                    crossWidth)

def lines():
    for row in range(1, boardRows):

        pygame.draw.line(
            display, 
            lineColor, 
            (0, squareSize * row), 
            (WIDTH, squareSize * row), 
            lines_width
            )
        
        pygame.draw.line(
            display, 
            lineColor, 
            (squareSize * row, 0), 
            (squareSize * row, HEIGHT), 
            lines_width
            )

def winning_line(row, col, direc):
    match direc:
        case 'horizontal':

            pygame.draw.line(
                display, 
                redColorCode, 
                (col * squareSize, row * squareSize + squareSize//2), 
                (col * squareSize + WIDTH, row * squareSize + squareSize//2), 
                win_lines_width
                )
            
        case 'vertical':
            pygame.draw.line(
                display, 
                redColorCode, 
                (col * squareSize + squareSize//2, row * squareSize), 
                (col * squareSize + squareSize//2, row * squareSize + HEIGHT), 
                win_lines_width
                )
            
        case 'asc_diagonal':
            pygame.draw.line(
                display, 
                redColorCode, 
                (0, HEIGHT), 
                (WIDTH, 0), 
                win_lines_width
                )
            
        case 'desc_diagonal':
            pygame.draw.line(
                display,
                redColorCode, 
                (0, 0), 
                (WIDTH, HEIGHT), 
                win_lines_width
                )

def check_win(player):
    for col in range(boardCols):
        if board[0][col] == board[1][col] == board[2][col] == player:
            winning_line(0, col, 'vertical')
            return True
    
    for row in range(boardRows):
        if board[row][0] == board[row][1] == board[row][2] == player:
            winning_line(row, 0, 'horizontal')
            return True

    if board[0][0] == board[1][1] == board[2][2] == player:
        winning_line(0, 0, 'desc_diagonal')
        return True

    if board[2][0] == board[1][1] == board[0][2] == player:
        winning_line(2, 0, 'asc_diagonal')
        return True

    return False

def apply_blur(surface, radius):
    if radius < 1:
        return surface

    scale = 0.9  / radius
    surf_size = surface.get_size()
    scale_size = (int(surf_size[0] * scale), int(surf_size[1] * scale))
    surf = pygame.transform.smoothscale(surface, scale_size)
    surf = pygame.transform.smoothscale(surf, surf_size)

    return surf

def winner(player):
    global game_over
    winner = "Player 1 (O)" if player == 1 else "Player 2 (X)"
    overlay = display.copy()
    overlay = apply_blur(overlay, 10)
    display.blit(overlay, (0, 0))
    
    message = font.render(f"{winner} wins!", True, textColorCode)

    display.blit(
        message, 
        (WIDTH//2 - message.get_width()//2, 
        HEIGHT//2 - message.get_height()//2 - 20)
        )

    restart_button = pygame.Rect(
        WIDTH//2 - 70, HEIGHT//2 + 20, 140, 40)
    
    pygame.draw.rect(
        display, 
        buttonColorCode, 
        restart_button
        )
    button_text = button_font.render("Play Again", True, textColorCode)
    
    display.blit(
        button_text, 
        (WIDTH//2 - button_text.get_width()//2, 
        HEIGHT//2 + 30)
        )

    pygame.display.update()

    while game_over:
        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN:

                if restart_button.collidepoint(event.pos):
                    game_over = False
                    restart()
                    break

            if event.type == pygame.MOUSEMOTION:

                if restart_button.collidepoint(event.pos):
                    pygame.draw.rect(display, buttonHoverColorCode, restart_button)

                else:
                    pygame.draw.rect(display, buttonColorCode, restart_button)
                
                display.blit(
                    button_text, 
                    (WIDTH//2 - button_text.get_width()//2, 
                    HEIGHT//2 + 30)
                    )
                pygame.display.update()

def restart():
    display.fill(BgColorCode)
    lines()
    for row in range(boardRows):
        for col in range(boardCols):
            board[row][col] = 0


pygame.init()

WIDTH, HEIGHT = 600, 600
lines_width = 10
win_lines_width = 15
boardRows, boardCols = 3, 3
squareSize = WIDTH // boardCols
circleRadios = squareSize // 3
circleWidth = 15
crossWidth = 25
Space = squareSize // 4
redColorCode = (255, 0, 0)
BgColorCode = (227, 255, 251)
lineColor = (20, 150, 140)
circleColorCode = (0, 110, 94)
crossColorCode = (66, 66, 66)
textColorCode = (0, 0, 0)
buttonColorCode = (233, 200, 200)
buttonHoverColorCode = (80, 80, 80)
ColorCode = (255, 0, 0)
ColorCode = (227, 255, 251)
Color = (20, 150, 140)
ColorCode = (0, 110, 94)
ColorCode = (66, 66, 66)
ColorCode = (0, 0, 0)
ColorCode = (233, 200, 200)
HoverColorCode = (80, 80, 80)
display = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption('XO GAME')
display.fill(BgColorCode)

font = pygame.font.Font(None, 36)
button_font = pygame.font.Font(None, 28)

board = []
for _ in range(boardRows):
    row = []
    for _ in range(boardCols):
        row.append(0)
    board.append(row)

lines()

player = 1
game_over = False

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:

            pygame.quit()
            sys.exit()

        if event.type == pygame.MOUSEBUTTONDOWN and not game_over:

            mouseX, mouseY = event.pos
            clicked_row = mouseY // squareSize
            clicked_col = mouseX // squareSize

            if board[clicked_row][clicked_col] == 0:
                board[clicked_row][clicked_col] = player

                if check_win(player):
                    game_over = True
                    shapes()
                    pygame.display.update()
                    winner(player)

                player = 1 if player == 2 else 2

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_r:

                restart()
                player = 1
                game_over = False

    shapes()
    pygame.display.update()

'''
board = []
for _ in range(boardRows):
    row = []
    for _ in range(boardCols):
        row.append(0)
    board.append(row)

lines()
'''