students = []
n = int(input())

for i in range(n):
    info = input().split()
    
    marks = list(map(float, info[3:]))
    grades, weights = marks[0::2], marks[1::2]
    
    weighted_sum = 0
    for g, u in zip(grades, weights):
        weighted_sum += g * u
    
    full_weights = sum(weights)
    avr = round(weighted_sum / full_weights, 2)

    stu = (
        info[0], "{} {}".format(info[1], info[2]),
        full_weights, avr)
    students.append(stu)
    

students.sort(key=lambda x: (-x[3], x[0]))

result =  open('result.csv', 'w')
text = 'student Number, Full Name, Num Of lessons, Avg\n'
result.write(text)
for stu in students:
    result.write(
        '{}, {}, {}, {}\n'.format(
            stu[0],
            stu[1],
            stu[2],
            stu[3],
        )
    )


