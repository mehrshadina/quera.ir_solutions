def main():
    with open('ketabha1.txt', 'r') as file1, open('ketabha2.txt', 'r') as file2:
        ketabha1 = file1.readlines()
        ketabha2 = file2.readlines()

    tedad_ketabha = {}
    asami_ketabha1 = set(ketab.strip() for ketab in ketabha1)

    for ketab in ketabha1:
        ketab_asli = ketab.strip()
        tedad_ketabha[ketab_asli] = tedad_ketabha.get(ketab_asli, 0) + 1

    for ketab in ketabha2:
        ketab_asli = ketab.strip()
        if ketab_asli in asami_ketabha1:
            tedad_ketabha.pop(ketab_asli, None)
        else:
            tedad_ketabha[ketab_asli] = tedad_ketabha.get(ketab_asli, 0) + 1

    ketabha_tedad = list(tedad_ketabha.items())
    ketabha_tedad.sort(key=lambda item: item[0])
    ketabha_morattab = sorted(ketabha_tedad, key=lambda item: item[1], reverse=True)

    with open('khorooji.txt', 'w') as file_khorooji:
        for ketab, tedad in ketabha_morattab:
            file_khorooji.write(f"{ketab} - {tedad}\n")

if __name__ == "__main__":
    main()
