import json

file = open("Data.json", "r")
data = json.load(file)

# in this loop we must analysis the Data.json file
for c in data["products"]:
    category = c["category"]
    items = c["items"]
    items = sorted(items, key=lambda x: x["current_stock"], reverse=True)
    csv_filename = "{}.csv".format(category)
    csvFile = open(csv_filename, "w")
    csvFile.write("code, name, initial_stock, current_stock, sold")
    for row in items:
        text = ', '.join(map(str, row.values())) + '\n'
        csvFile.write(text)

# we must create a text for report file
# in lines down we do it
interview = 'INTERVIEW:\n\n'
for c in data["products"]:
    max_stock_item = max(c["items"], key=lambda x: x["current_stock"])
    interview += f"highest stock: {max_stock_item['name']} -- Current Stock: {max_stock_item['current_stock']}\n\n"

# here we save the report
with open("report.txt", "w") as report_file:
    report_file.write(interview)

