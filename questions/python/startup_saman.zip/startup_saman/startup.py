import json
import matplotlib.pyplot as plt

def load_json_file(filename):
    with open(filename, 'r') as file:
        return json.load(file)

def load_log_file(filename):
    with open(filename, 'r') as file:
        return file.readlines()

def process_actions(actions, users):
    for act in actions:
        acts = act.split()
        command, user = acts[0], acts[1]

        if command == 'ADD':
            amount = int(acts[2])
            if user in users:
                users[user]['balance'] += amount

        elif command == 'DELETE':
            if user in users:
                del users[user]

        elif command == 'CREATE':
            age = int(acts[2])
            if user in users:
                users[user]['age'] = age
            else:
                users[user] = {'balance': 0, 'age': age}

def save_json_file(data, filename):
    with open(filename, 'w') as file:
        json.dump(data, file)

def extract_ages(users):
    return [user['age'] for user in users.values()]

def plot_histogram(data, filename):
    plt.hist(
        data, 
        bins=range(min(data), max(data) + 2),
        edgecolor='brown'
    )
    plt.xlabel('Age')
    plt.ylabel('Frequency')
    plt.title('Histogram of Ages')
    plt.savefig(filename)
    plt.show()

def main():
    users = load_json_file('users.json')
    actions = load_log_file('actions.log')
    process_actions(actions, users)
    save_json_file(users, 'users.json')
    user_ages = extract_ages(users)
    plot_histogram(user_ages, 'hist.png')

main()
