def main():
    books1 = open('books1.txt', 'r')
    books2 = open('books2.txt', 'r')

    book_count = {}
    books_name1 = set()
    for book in books1:
        real_book = book.strip()
        if real_book in book_count:
            book_count[real_book] += 1
        else:
            book_count[real_book] = 1
        books_name1.add(real_book)

    for book in books2:
        real_book = book.strip()
        if real_book in books_name1:
            del book_count[real_book]
        elif real_book in book_count:
            book_count[real_book] += 1
        else:
            book_count[real_book] = 1

    sorted_books = sorted(book_count.items(), key=lambda x: (-x[1], x[0]))
    print(sorted_books)
    file = open('output.txt', 'w')
    for book, count in sorted_books:
        file.write(f"{book} - {count}\n")

main()