import arcade

WIDTH, HEIGHT = 600, 600
BOARD_ROWS, BOARD_COLS = 3, 3
SQUARE_SIZE = WIDTH // BOARD_COLS
CIRCLE_RADIUS = SQUARE_SIZE // 3
CIRCLE_WIDTH = 15
CROSS_WIDTH = 25
SPACE = SQUARE_SIZE // 4
LINES_WIDTH = 10
WIN_LINES_WIDTH = 15
RED_COLOR = arcade.color.RED
BG_COLOR = arcade.color.LIGHT_CYAN
LINE_COLOR = arcade.color.DARK_GREEN
CIRCLE_COLOR = arcade.color.DARK_CYAN
CROSS_COLOR = arcade.color.CHARCOAL
TEXT_COLOR = arcade.color.BLACK
BUTTON_COLOR = arcade.color.PALE_ROBIN_EGG_BLUE
BUTTON_HOVER_COLOR = arcade.color.DIM_GRAY

board = [[0 for _ in range(BOARD_COLS)] for _ in range(BOARD_ROWS)]
player = 1
game_over = False

def draw_shapes():
    for row in range(BOARD_ROWS):
        for col in range(BOARD_COLS):
            x = col * SQUARE_SIZE + SQUARE_SIZE // 2
            y = row * SQUARE_SIZE + SQUARE_SIZE // 2
            if board[row][col] == 1:
                arcade.draw_circle_outline(x, y, CIRCLE_RADIUS, CIRCLE_COLOR, CIRCLE_WIDTH)
            elif board[row][col] == 2:
                arcade.draw_line(col * SQUARE_SIZE + SPACE, row * SQUARE_SIZE + SQUARE_SIZE - SPACE,
                                 col * SQUARE_SIZE + SQUARE_SIZE - SPACE, row * SQUARE_SIZE + SPACE,
                                 CROSS_COLOR, CROSS_WIDTH)
                arcade.draw_line(col * SQUARE_SIZE + SPACE, row * SQUARE_SIZE + SPACE,
                                 col * SQUARE_SIZE + SQUARE_SIZE - SPACE, row * SQUARE_SIZE + SQUARE_SIZE - SPACE,
                                 CROSS_COLOR, CROSS_WIDTH)

def draw_lines():
    for row in range(1, BOARD_ROWS):
        arcade.draw_line(0, SQUARE_SIZE * row, WIDTH, SQUARE_SIZE * row, LINE_COLOR, LINES_WIDTH)
        arcade.draw_line(SQUARE_SIZE * row, 0, SQUARE_SIZE * row, HEIGHT, LINE_COLOR, LINES_WIDTH)

def draw_winning_line(row, col, direction):
    if direction == 'horizontal':
        arcade.draw_line(0, row * SQUARE_SIZE + SQUARE_SIZE // 2, WIDTH, row * SQUARE_SIZE + SQUARE_SIZE // 2, RED_COLOR, WIN_LINES_WIDTH)
    elif direction == 'vertical':
        arcade.draw_line(col * SQUARE_SIZE + SQUARE_SIZE // 2, 0, col * SQUARE_SIZE + SQUARE_SIZE // 2, HEIGHT, RED_COLOR, WIN_LINES_WIDTH)
    elif direction == 'asc_diagonal':
        arcade.draw_line(0, HEIGHT, WIDTH, 0, RED_COLOR, WIN_LINES_WIDTH)
    elif direction == 'desc_diagonal':
        arcade.draw_line(0, 0, WIDTH, HEIGHT, RED_COLOR, WIN_LINES_WIDTH)

def check_win(player):
    for col in range(BOARD_COLS):
        if board[0][col] == board[1][col] == board[2][col] == player:
            draw_winning_line(0, col, 'vertical')
            return True
    for row in range(BOARD_ROWS):
        if board[row][0] == board[row][1] == board[row][2] == player:
            draw_winning_line(row, 0, 'horizontal')
            return True
    if board[0][0] == board[1][1] == board[2][2] == player:
        draw_winning_line(0, 0, 'desc_diagonal')
        return True
    if board[2][0] == board[1][1] == board[0][2] == player:
        draw_winning_line(2, 0, 'asc_diagonal')
        return True
    return False

class MyGame(arcade.Window):
    def __init__(self):
        super().__init__(WIDTH, HEIGHT, "XO Game")
        arcade.set_background_color(BG_COLOR)
        self.restart_button = arcade.create_rectangle_filled(WIDTH//2, HEIGHT//2 + 20, 140, 40, BUTTON_COLOR)
        self.font = arcade.load_font("/home/skyboy/w/python/sharif/XO_game copy/ShortBaby.ttf")
        self.button_font = arcade.load_font("/home/skyboy/w/python/sharif/XO_game copy/ShortBaby.ttf")

    def on_draw(self):
        arcade.start_render()
        draw_lines()
        draw_shapes()
        if game_over:
            self.draw_winner(player)
        arcade.finish_render()

    def on_mouse_press(self, x, y, button, modifiers):
        global player, game_over
        if not game_over:
            clicked_row = y // SQUARE_SIZE
            clicked_col = x // SQUARE_SIZE
            if board[clicked_row][clicked_col] == 0:
                board[clicked_row][clicked_col] = player
                if check_win(player):
                    game_over = True
                player = 1 if player == 2 else 2
        elif self.is_button_clicked(x, y):
            self.restart()

    def on_mouse_motion(self, x, y, dx, dy):
        if self.is_button_hovered(x, y):
            self.restart_button.color = BUTTON_HOVER_COLOR
        else:
            self.restart_button.color = BUTTON_COLOR

    def is_button_clicked(self, x, y):
        return self.restart_button.center_x - self.restart_button.width / 2 <= x <= self.restart_button.center_x + self.restart_button.width / 2 and \
               self.restart_button.center_y - self.restart_button.height / 2 <= y <= self.restart_button.center_y + self.restart_button.height / 2

    def is_button_hovered(self, x, y):
        return WIDTH // 2 - 70 <= x <= WIDTH // 2 + 70 and \
               HEIGHT // 2 + 20 - 20 <= y <= HEIGHT // 2 + 20 + 20

    def restart(self):
        global board, player, game_over
        board = [[0 for _ in range(BOARD_COLS)] for _ in range(BOARD_ROWS)]
        player = 1
        game_over = False

    def draw_winner(self, player):
        winner = "Player 1 (O)" if player == 1 else "Player 2 (X)"
        arcade.draw_text(f"{winner} wins!", WIDTH // 2, HEIGHT // 2 - 20, TEXT_COLOR, font_size=36, anchor_x="center")
        arcade.draw_rectangle_filled(WIDTH // 2, HEIGHT // 2 + 20, 140, 40, BUTTON_COLOR)
        arcade.draw_text("Play Again", WIDTH // 2, HEIGHT // 2 + 30, TEXT_COLOR, font_size=28, anchor_x="center")

def main():
    game = MyGame()
    arcade.run()


main()
