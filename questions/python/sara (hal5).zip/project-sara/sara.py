import csv
from datetime import datetime
import matplotlib.pyplot as plt

class WeatherDataLoader:
    def __init__(self, file_path):
        self.file_path = file_path
        self.data = []
        self.load_data()
        
    def load_data(self):
        with open(self.file_path, 'r') as datas:
            csvdata = csv.DictReader(datas)
            for row in csvdata:
                row['datetime'] = datetime.strptime(row['datetime'], '%Y-%m-%d')
                row['tempmax'] = float(row['tempmax'])
                row['tempmin'] = float(row['tempmin'])
                row['temp'] = float(row['temp'])
                row['windspeed'] = float(row['windspeed'])
                row['preciptype'] = row['preciptype'].split(',')
                row['month'] = row['datetime'].strftime('%B')
                self.data.append(row)

class WeatherAnalyzer:
    def __init__(self, data):
        self.data = data

    def rainy_days_percentage(self):
        rainy_days = sum(1 for row in self.data if 'rain' in row['preciptype'])
        total_days = len(self.data)
        return (rainy_days / total_days) * 100

    def max_temp_date(self):
        return max(self.data, key=lambda x: x['tempmax'])['datetime']

    def min_temp_date(self):
        return min(self.data, key=lambda x: x['tempmin'])['datetime']

    def storm_days(self):
        return [str(row['datetime']) for row in self.data if row['windspeed'] >= 35]

    def temperature_by_month(self, month):
        month_data = []
        dates = []
        temps = []

        for row in self.data:
            if row['month'] == month:
                month_data.append(row)
                dates.append(row['datetime'])
                temps.append(row['temp'])

        
        plt.figure(figsize=(10, 5))
        plt.plot(dates, temps, marker='o')
        plt.title(f'Temperature in {month}')
        plt.xlabel('Date')
        plt.ylabel('Temperature (°C)')
        plt.grid(True)
        plt.show()

    def windspeed_time(self):
        dates = []
        wind_speeds = []

        for row in self.data:
            dates.append(row['datetime'])
            wind_speeds.append(row['windspeed'])

        
        plt.figure(figsize=(10, 5))
        plt.plot(dates, wind_speeds, marker='o')
        plt.title('Wind Speed Over Time')
        plt.xlabel('Date')
        plt.ylabel('Wind Speed (mph)')
        plt.grid(True)
        plt.show()

    def condition_chart(self):
        condition_counts = {}
        for row in self.data:
            conditions = row['conditions'].split(', ')
            for condition in conditions:
                condition_counts[condition] = condition_counts.get(condition, 0) + 1
        
        labels = list(condition_counts.keys())
        sizes = list(condition_counts.values())
        
        plt.figure(figsize=(8, 8))
        plt.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=140)
        plt.title('Weather Conditions Pie Chart')
        plt.show()

    def main_menu(self):
        print(f"Percentage of rainy days in 2023: {self.rainy_days_percentage():.2f}%")
        print(f"Highest temperature recorded on: {self.max_temp_date()}")
        print(f"Lowest temperature recorded on: {self.min_temp_date()}")
        print(f"Days with potential storms: {self.storm_days()}")

        while True:
            print("\nSelect an option to display data:\n"
                  "1. wind speed over time\n"
                  "2. temperature by month\n"
                  "3. condition pie chart\n"
                  "4. Exit")
            
            choice = input("Enter your choice: ")
            
            if choice == '1':
                self.windspeed_time()
            elif choice == '2':
                month = input("Enter the month (March, et. ")
                self.temperature_by_month(month)
            elif choice == '3':
                self.condition_chart()
            elif choice == '4':
                break
            else:
                print("Invalid choice. Please try again.")
                break


loader = WeatherDataLoader('Daily_Weather_Report.csv')
analyzer = WeatherAnalyzer(loader.data)
analyzer.main_menu()
