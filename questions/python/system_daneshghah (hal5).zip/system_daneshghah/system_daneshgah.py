import csv

class Student:
    def __init__(self, student_number, first_name, last_name, grades_weights):
        self.student_number = student_number
        self.full_name = f"{first_name} {last_name}"
        self.num_of_units = sum(grades_weights[1::2])
        self.avg = self.calculate_weighted_average(grades_weights)

    def calculate_weighted_average(self, grades_weights):
        grades = grades_weights[0::2]
        weights = grades_weights[1::2]
        weighted_sum = sum(g * w for g, w in zip(grades, weights))
        return round(weighted_sum / self.num_of_units, 2)

    def to_csv_row(self):
        return f"{self.student_number}, {self.full_name}, {self.num_of_units}, {self.avg}"

class StudentProcessor:
    def __init__(self):
        self.students = []

    def add_student(self, student_info):
        grades_weights = list(map(float, student_info[3:]))
        student = Student(student_info[0], student_info[1], student_info[2], grades_weights)
        self.students.append(student)

    def sort_students(self):
        self.students.sort(key=lambda x: (-x.avg, x.student_number))

    def write_to_csv(self, filename='result.csv'):
        with open(filename, 'w', newline='') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(['studentNumber', 'FullName', 'Num_Of_Units', 'Avg'])
            for student in self.students:
                writer.writerow([student.student_number, student.full_name, student.num_of_units, student.avg])

def main():
    student_processor = StudentProcessor()
    n = int(input("Enter number of students: "))
    
    for _ in range(n):
        student_info = input().split()
        student_processor.add_student(student_info)
    
    student_processor.sort_students()
    student_processor.write_to_csv()

if __name__ == "__main__":
    main()
