import json

file = open("Data.json", "r")
json_data = json.load(file)

def process():
    for kategori in json_data["products"]:
        emas = sorted(kategori["items"], key=lambda x: x["current_stock"], reverse=True)
        csv_file = open(kategori["category"] + "_sorted.csv", "w")
        csv_file.write("code, name, initial_stock, current_stock, sold")

        for qator in emas:
            text = ','.join(map(str, qator.values())) + '\n'
            csv_file.write(text)

def process_2():
    matn = ''
    for kategori in json_data["products"]:
        max_stock_item = max(
            kategori["items"], 
            key=lambda x: x["current_stock"]
            )
        matn += f"Category: " + kategori["category"] + f"\nbaland hisob: {max_stock_item['name']} \n Kod: {max_stock_item['code']} \n Joriy Hisob: {max_stock_item['current_stock']}\n\n"
    return matn

def process_3(matn):
    with open("report.txt", "w") as report_file:
        report_file.write(matn)

process()
matn = process_2()
process_3(matn)