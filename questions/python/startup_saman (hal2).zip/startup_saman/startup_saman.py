import json
import matplotlib.pyplot as plt

file = open('users.json', 'r')
all_users = json.load(file)

file = open('actions.log', 'r')
all_actions = file.readlines()

for action in all_actions:
    splited_line = action.split()
    command, username = splited_line[0], splited_line[1]

    #print(users)
    #print(parts)

    match command:
        case 'ADD':
            amount = int(splited_line[2])
            if username in all_users:
                all_users[username]['balance'] += amount

        case 'CREATE':
            age = int(splited_line[2])
            if username in all_users:
                all_users[username]['age'] = age
            else:
                all_users[username] = {'balance': 0, 'age': age}

        case 'DELETE':
            if username in all_users:
                del all_users[username]

file = open('users.json', 'w')
json.dump(all_users, file)

ages = []
for information in all_users.values():
    ages.append(information['age'])

plt.hist(
    ages, 
    bins = range(
        min(ages), 
        max(ages) + 2
        ), 
    edgecolor='black'
    )
plt.xlabel('age')
plt.ylabel('frequency')
plt.title('Historygram of Ages')
plt.savefig('hist.png')
plt.show()
